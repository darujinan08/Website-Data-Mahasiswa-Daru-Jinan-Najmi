# Aplikasi Manajemen Data Mahasiswa

Ini adalah aplikasi web sederhana untuk mengelola data mahasiswa. Dibuat dengan PHP, MySQL, HTML, CSS, dan JavaScript. Bisa digunakan untuk tracking informasi mahasiswa seperti NIM, nama, alamat, tanggal lahir, jenis kelamin, dan usia.

Aplikasi ini punya dua halaman utama:
- **HOME**: Untuk melihat data mahasiswa dan cari berdasarkan nama
- **ADMIN**: Untuk tambah, edit, atau hapus data mahasiswa

## Cara Instalasi

Pertama, pastikan sudah punya XAMPP terinstall. Kalau belum, download dari [sini](https://www.apachefriends.org/).

### Langkah-langkah:

1. **Extract folder ini ke:** `C:\xampp\htdocs\Web Data Mahasiswa\`

2. **Buka XAMPP Control Panel** dan jalankan Apache dan MySQL

3. **Setup database:**
   - Buka browser: `http://localhost/phpmyadmin`
   - Login dengan username: `root` (passwordnya kosong)
   - Klik Import, pilih file `docs/database_init.sql`
   - Klik Go

4. **Buka aplikasi:**
   - Ketik di browser: `http://localhost/Web%20Data%20Mahasiswa/`

Kalau berhasil, seharusnya bisa lihat halaman HOME dengan data mahasiswa.

## Fitur-Fitur

**Di Halaman HOME:**
- Lihat semua data mahasiswa (terurut dari NIM terbesar)
- Cari data berdasarkan nama
- Lihat statistik jumlah mahasiswa berdasarkan jenis kelamin
- Usia otomatis dihitung dari tanggal lahir

**Di Halaman ADMIN:**
- Tambah data mahasiswa baru
- Edit data (tapi NIM tidak bisa diubah)
- Hapus data dengan konfirmasi
- Lihat tabel semua data

## Data yang Disimpan

Setiap mahasiswa punya data:
- **NIM** - Nomor induk (unik, tidak bisa sama)
- **Nama** - Nama lengkap
- **Alamat** - Alamat tinggal
- **Tanggal Lahir** - Untuk hitung usia
- **Jenis Kelamin** - Laki-laki atau Perempuan
- **Usia** - Otomatis dihitung, tidak perlu diinput

## Struktur Folder

```
Web Data Mahasiswa/
├── index.php              (halaman HOME)
├── admin/
│   ├── index.php          (halaman ADMIN)
│   ├── add.php            (proses tambah)
│   ├── edit.php           (proses edit)
│   └── delete.php         (proses hapus)
├── includes/
│   ├── config.php         (setting database)
│   └── functions.php      (fungsi-fungsi)
├── assets/
│   ├── css/style.css      (styling)
│   └── js/script.js       (validasi & interaksi)
└── docs/
    ├── ANALISIS_SPESIFIKASI.md
    ├── PANDUAN_SETUP.md
    ├── DOKUMENTASI_KODE.md
    └── database_init.sql
```

## Cara Menggunakan

**Lihat Data:**
1. Buka halaman HOME
2. Data sudah tampil otomatis
3. Kalo mau cari, ketik nama di kolom cari

**Tambah Data:**
1. Buka halaman ADMIN
2. Klik tombol "TAMBAH DATA"
3. Isi form dengan data mahasiswa
4. Setiap field wajib diisi
5. Klik tombol Simpan
6. Kalau berhasil, akan ada notifikasi sukses

**Edit Data:**
1. Di ADMIN, cari data yang mau diedit
2. Klik tombol Edit (kuning)
3. Form akan muncul dengan data lama
4. Ubah data yang ingin diubah (tapi NIM tidak bisa dirubah)
5. Klik tombol Perbarui
6. Selesai!

**Hapus Data:**
1. Di ADMIN, cari data yang mau dihapus
2. Klik tombol Hapus (merah)
3. Ada popup untuk konfirmasi
4. Klik "Ya, Hapus" untuk benar-benar menghapus
5. Data akan hilang dari sistem

## Teknologi yang Dipakai

- **Frontend:** HTML5, CSS3, JavaScript
- **Framework:** Bootstrap 5 (buat styling)
- **Icons:** Bootstrap Icons
- **Backend:** PHP 7.4+
- **Database:** MySQL 5.7+
- **Library Tambahan:** SweetAlert2 (buat konfirmasi hapus yang cantik)

Semua library diambil dari CDN, jadi tidak perlu install apapun selain XAMPP.

## Data Sample

Database sudah berisi 5 data mahasiswa untuk testing. Ini data-datanya:

| NIM   | Nama | Alamat | Lahir | Gender |
|-------|------|--------|-------|--------|
| 19001 | Budi Santoso | Jl. Merdeka No. 10, Jakarta | 15-05-2003 | Laki-laki |
| 19002 | Siti Nurhaliza | Jl. Ahmad Yani No. 25, Bandung | 22-08-2002 | Perempuan |
| 19003 | Ahmad Wijaya | Jl. Sudirman No. 45, Surabaya | 10-01-2004 | Laki-laki |
| 19004 | Linda Permatasari | Jl. Gatot Subroto No. 12, Medan | 18-03-2003 | Perempuan |
| 19005 | Rudi Hermawan | Jl. Diponegoro No. 30, Yogyakarta | 05-11-2002 | Laki-laki |

Bebas untuk tambah, edit, atau hapus data ini sesuai kebutuhan.

## Masalah Umum & Solusi

**Halaman tidak muncul (404)?**
- Pastikan folder sudah di `C:\xampp\htdocs\Web Data Mahasiswa\`
- Coba ctrl+F5 di browser untuk clear cache
- Pastikan spelling URL benar (perhatikan spasi)

**Database connection error?**
- Pastikan MySQL sudah nyala di XAMPP
- Buka `includes/config.php` dan cek settingnya
- Username harusnya `root`, password kosong
- Database name harusnya `db_mahasiswa`
- Kalau masih error, coba import database lagi

**Form tidak bisa submit?**
- Clear cache browser (ctrl+shift+delete)
- Buka dev tools (F12) lihat ada error atau tidak
- Coba refresh halaman
- Pastikan browser support JavaScript

**Data tidak sesuai yang diinput?**
- Ada validasi di backend, jadi pastikan data valid
- NIM harus unik (tidak boleh sama dengan yang sudah ada)
- Tanggal lahir tidak boleh di masa depan
- Umur minimal harus 1 tahun


## Dokumentasi Detail

Detail dokumentasi lengkap di folder `docs/`:

- `ANALISIS_SPESIFIKASI.md` - Penjelasan tentang aplikasi
- `PANDUAN_SETUP.md` - Panduan instalasi lengkap
- `DOKUMENTASI_KODE.md` - Penjelasan setiap kode


## Lisensi

Aplikasi ini bebas digunakan oleh semua pengguna
---


